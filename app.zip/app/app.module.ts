import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { CreatePolicyComponent } from './create-policy/create-policy.component';
//import { DataTablesModule } from 'angular-datatables';
//import {AutocompleteLibModule} from 'angular-ng-autocomplete';
import { PolicyListComponent } from './policies_list/policies_list.component';
//import {MatButtonModule,MatCheckboxModule,MatToolbarModule} from '@angular/material';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    CreatePolicyComponent,
    PolicyListComponent,
    //AutocompleteLibModule,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    Ng2SearchPipeModule,
    BrowserAnimationsModule
    //DataTablesModule
   // MatButtonModule,
    //MatCheckboxModule,
    //MatToolbarModule
  ],bootstrap: [AppComponent]
})
export class AppModule { }
