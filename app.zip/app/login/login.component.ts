import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { PolicyService } from '../_services/policy.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  result: any
  msg: boolean = false;
  loginForm: FormGroup
  isLogin!: Boolean;
  admin!: boolean;
  user!: boolean;
  constructor(private fb: FormBuilder, private router: Router, private policyservice: PolicyService) {
    this.loginForm = this.fb.group({
      userId: this.fb.control('', Validators.required),
      password: this.fb.control('', Validators.required)

    })
  }

  ngOnInit(): void {
  }

  onSubmit() {
    if (this.loginForm.valid) {
      this.policyservice.Login(this.loginForm.value).subscribe(data => {
        this.result = Object.values(data);
        
        if (this.result[0] == true) {

          this.isLogin = true;

          if (this.result[1] == "user") {
            this.user = true;
            this.router.navigate(['/policylist']);

          } else if (this.result[1] == "admin") {
            this.admin = true;
            this.router.navigate(['/createpolicy']);
          }
          Swal.fire('Success!', 'Login successfull', 'success')
        } else {
          Swal.fire('Invalid', 'UserId or Password is inCorrect', 'error');
        }
      })
    } else {
      this.msg = true;
    }
  }


  check(input: string) {
    return (this.loginForm.get(input)?.invalid && this.loginForm.get(input)?.touched) || (this.loginForm.get(input)?.invalid && this.msg)
  }
  registration() {
    this.router.navigate(['/register']);
  }
}