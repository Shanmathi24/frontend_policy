import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { PolicyService } from '../_services/policy.service';
import { LoginComponent } from './login.component';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(() => {
    const formBuilderStub = () => ({
      group: (object: any) => ({}),
      control: (string: any, required: any) => ({})
    });
    const routerStub = () => ({ navigate: (array: any) => ({}) });
    const policyServiceStub = () => ({
      Login: (value: any) => ({ subscribe: (f: (arg0: {}) => any) => f({}) })
    });
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [LoginComponent],
      providers: [
        { provide: FormBuilder, useFactory: formBuilderStub },
        { provide: Router, useFactory: routerStub },
        { provide: PolicyService, useFactory: policyServiceStub }
      ]
    });
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`msg has default value`, () => {
    expect(component.msg).toEqual(false);
  });

  describe('onSubmit', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      const policyServiceStub: PolicyService = fixture.debugElement.injector.get(
        PolicyService
      );
      spyOn(routerStub, 'navigate').and.callThrough();
      spyOn(policyServiceStub, 'Login').and.callThrough();
      component.onSubmit();
      expect(routerStub.navigate).toHaveBeenCalled();
      expect(policyServiceStub.Login).toHaveBeenCalled();
    });
  });

  describe('registration', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      spyOn(routerStub, 'navigate').and.callThrough();
      component.registration();
      expect(routerStub.navigate).toHaveBeenCalled();
    });
  });
});
