export class LoginDetails {
    userId!:string;
    password!:string;
}
