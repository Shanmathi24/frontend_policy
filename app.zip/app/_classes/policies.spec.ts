import { Policies } from './policies';

describe('Policies', () => {
  it('should create an instance', () => {
    expect(new Policies()).toBeTruthy();
  });
});
