import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { PolicyService } from '../_services/policy.service';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { RegisterComponent } from './register.component';

describe('RegisterComponent', () => {
  let component: RegisterComponent;
  let fixture: ComponentFixture<RegisterComponent>;

  beforeEach(() => {
    const policyServiceStub = () => ({
      Register: (value: any) => ({ subscribe: (f: (arg0: {}) => any) => f({}) })
    });
    const formBuilderStub = () => ({
      group: (object: any) => ({}),
      control: (string: any, array: any) => ({})
    });
    const routerStub = () => ({ navigate: (array: any) => ({}) });
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [RegisterComponent],
      providers: [
        { provide: PolicyService, useFactory: policyServiceStub },
        { provide: FormBuilder, useFactory: formBuilderStub },
        { provide: Router, useFactory: routerStub }
      ]
    });
    fixture = TestBed.createComponent(RegisterComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`msg has default value`, () => {
    expect(component.msg).toEqual(false);
  });

  describe('onSubmit', () => {
    it('makes expected calls', () => {
      const policyServiceStub: PolicyService = fixture.debugElement.injector.get(
        PolicyService
      );
      spyOn(component, 'login').and.callThrough();
      spyOn(policyServiceStub, 'Register').and.callThrough();
      component.onSubmit();
      expect(component.login).toHaveBeenCalled();
      expect(policyServiceStub.Register).toHaveBeenCalled();
    });
  });

  describe('login', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      spyOn(routerStub, 'navigate').and.callThrough();
      component.login();
      expect(routerStub.navigate).toHaveBeenCalled();
    });
  });
});
