import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PolicyService } from '../_services/policy.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-create-policy',
  templateUrl: './create-policy.component.html',
  styleUrls: ['./create-policy.component.css']
})
export class CreatePolicyComponent implements OnInit {

  policyForm: FormGroup
  msg:boolean=false;
  constructor(private router: Router, private fb: FormBuilder, private policyService: PolicyService) {
    this.policyForm = this.fb.group({
      policyName: this.fb.control('', Validators.required),
      startDate: this.fb.control('', Validators.required),
      duration: this.fb.control('', Validators.required),
      company: this.fb.control('', Validators.required),
      initialDeposit:this.fb.control('', Validators.required),
      policyType:this.fb.control('', Validators.required),
      userType:this.fb.control('', Validators.required),
      termsPerYear:this.fb.control('', Validators.required),
      termAmount:this.fb.control('', Validators.required),
      interest:this.fb.control('', Validators.required)
    })
  }

  ngOnInit(): void {
  }

  onSubmit() {
    if (this.policyForm.valid) {
      this.policyService.policyregister(this.policyForm.value).subscribe(data => {
        Swal.fire('Success!', 'Policy added successfully', 'success')
        this.router.navigate(['/policylist']);
      });
    }}

  check(input: string) {
    return (this.policyForm.get(input)?.invalid && this.policyForm.get(input)?.touched) || (this.policyForm.get(input)?.invalid && this.msg)
  }
}