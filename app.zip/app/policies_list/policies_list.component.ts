import { Component, OnInit, Output, ViewChild } from '@angular/core';
import { map, Observable } from 'rxjs';
import { Policies } from '../_classes/policies';
import { PolicyService } from '../_services/policy.service';
import * as jsPDF from 'jspdf';
import { HttpHeaders } from '@angular/common/http';
import { EventEmitter } from 'stream';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-policies_list',
  templateUrl: './policies_list.component.html',
  styleUrls: ['./policies_list.component.css']
})
export class PolicyListComponent implements OnInit {
  policyType!: string;
  //currentPolicy: string[]=[];
  policylist!:Policies;
  policies: any;
  search: any;
  policy!: Policies;
  policy1: Policies[] = [];
  PDF_URL: any;
  http: any;
  private policysearch = new Policies();
  data: any;
  PolicyType: any;
  Duration: any;
  Company: any;
  PolicyId: any;
  PolicyName: any;
  constructor(private downloadpdfService: PolicyService, private policyService: PolicyService) { }

  ngOnInit(): void {
    this.policies = this.policyService.getPolicies();
  }


  getPolicies() {
    this.policyService.getPolicies();

  }
  
  downloadpdf(policyId:string) {
    this.policyService.getdocuments(policyId);

  }









  searchPolicies() {
    this.policyService.searchPolicy()
    
  }










}
//     selectEvent(event:any){
//         this.currentPolicy..=event
//       }
// }


// function subscribe(arg0: (response: any) => void) {
//   throw new Error('Function not implemented.');
// 

